import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpConnectService } from '../services/http-connect.service';
import { Member } from '../classes/member';
import * as moment from 'moment';

// Declaramos las variables para jQuery
declare var jQuery: any;
declare var $: any;

@Component({
  selector: 'aca-member-form',
  templateUrl: './member-form.component.html',
  styleUrls: ['./member-form.component.css']
})
export class MemberFormComponent implements OnInit {
  public idRecibido: string; // Si edición, el id de miembro. Si nuevo, undefined
  public member: Member; // Objeto para los datos del miembro
  // Datos de miembro
  public doi: string; // Enlace con el formulario
  public nombre: string; // Enlace con el formulario
  public doiGrabar: string; // Para procesar sin espacios
  public nombreGrabar: string; // Para procesar sin espacios
  public fecha_de_ingreso: string; // Enlace con el formulario
  public genero: string; // Enlace con el formulario
  public avatar: string; // Enlace con el formulario
  public avatarFile: any; // El fichero del avatar procedente del campo file
  public imageToShow: string; // El avatar en base64, si lo hay (enlaza con el src del formulario)
  public activo: string; // Enlace con el formulario
  public dataPack: FormData; // Empaquetado de todo (inc. avatar) para mandar a grabar.

  /* Flags de resultados. Determinarán que en el formulario se muestren
  mensajes con los resultados de la operación. */
  public errorEnAvatar = false;
  public errorEnDoi = false;
  public doiRepetido = false;
  public errorEnNombre = false;
  public errorEnFecha = false;
  public errorEnGenero = false;
  public errorDeProceso = false;
  public registroGrabado = false;

  /* En la firma del constructor creamos un objeto de la clase HttpConnectService,
  para poder acceder a las conexiones con API's.
  También creamos un objeto de la clase ActivatedRoute, porque si llegamos hasta aquí
  desde edición debemos poder recuperar de la ruta el id del usuario a editar. */
  constructor(
    private connectService: HttpConnectService,
    private ruta: ActivatedRoute
  ) {
    this.idRecibido = this.ruta.snapshot.params['id'];
    /* Si hay un id recibido estamos en edición, por lo que
    lo primero es leer los datos del miembro que vamos a editar. */
    if (this.idRecibido !== undefined) {
      this.readActualData(); // Leer los datos actuales del miembro, si estamos en edición.
    } else {
      /* Para nuevo miembro, se muestra, por defecto, el avatar genérico,
      y se establece la fecha de alta como la del día en curso. */
      this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
      this.setActualDate();
    }
  }

  ngOnInit() {
    $(document).prop('title', 'Formulario de miembro');
    $('.menuLink').removeClass('active');
    /* Si es un nuevo miembro se activan las etiquetas de la barra de menús.
    En edición, no las activo, por criterio personal. */
    if (this.idRecibido === undefined) {
      $('#MembersMenuLink').addClass('active');
      $('#MemberFormMenuLink').addClass('active');
    }
  }

  /* Cuando se pulsa el botón de grabación, se hace una validación previa de los datos.
  Si cumplen, se graba. Si no, se avisa del fallo. */
  public checkRecord() {
    this.clearNotice();
    this.doiGrabar = (this.doi === undefined || this.doi === null) ? '' : this.doi;
    this.nombreGrabar = (this.nombre === undefined || this.nombre === null) ? '' : this.nombre;
    this.doiGrabar = this.doiGrabar.trim();
    this.nombreGrabar = this.nombreGrabar.trim();
    if (this.doiGrabar === '' || this.doiGrabar === undefined) {
      this.errorEnDoi = true;
    } else if (this.nombreGrabar === '' || this.nombreGrabar === undefined) {
      this.errorEnNombre = true;
    } else if (this.fecha_de_ingreso === '') {
      this.errorEnFecha = true;
    } else if (this.genero === '' || this.genero === undefined) {
      this.errorEnGenero = true;
    } else if (!this.errorEnAvatar) {
      /* Si no hay errores, y tampoco en el avatar
      Se graba el registro.
      Para nuevas altas, se pone '0' como id del usuario, para cumplir con la firma del constructor
      de la clase. Será la API la que si encuentra '0' sepa que es un nuevo registro, y si encuentra
      otro valor sepa que es una edición. */
      this.member = new Member(
        '0',
        this.doiGrabar,
        this.nombreGrabar,
        this.fecha_de_ingreso,
        this.genero
      );
      this.buildDataPack(); // Empaquetamos todo (datos y avatar) en un solo objeto.
      this.saveRecord(); // Para grabar el objeto.
    }
  }

  /* El método que empaqueta datos y avatar en un objeto FormData */
  private buildDataPack() {
    this.dataPack = new FormData();
    this.dataPack.append('User', JSON.stringify(this.member));
    this.dataPack.append('Avatar', this.avatarFile);
  }

  /* Reservado para cuando se monte la edición. */
  private readActualData() {}

  /* Creado el objeto FormData se le pasa al servicio que lo envia a la API. */
  private saveRecord() {
    this.connectService
      .saveRecod$(this.dataPack)
      .subscribe(this.saveSuccess.bind(this), this.catchError.bind(this));
  }

  /* Si el proceso de alta o edición ha finalizado correctamente. */
  private saveSuccess(result) {
    if (result === '0') {
      this.registroGrabado = true;
    } else if (result === '23000') {
      this.doiRepetido = true;
    } else if (result === '42S22') {
      this.errorDeProceso = true;
    }
    this.restoreData();
  }

  /* Si hay errores en las llamadas a las API's */
  private catchError() {
    this.errorDeProceso = true;
  }

  /* Se borran las notificaciones que se hayan podido producir.
  Este método se desencadena cuando se pone el foco en algún campo,
  o se pulsa el botón de envío o de reset. */
  public clearNotice() {
    this.errorEnDoi = false;
    this.doiRepetido = false;
    this.errorEnNombre = false;
    this.errorEnFecha = false;
    this.errorEnGenero = false;
    this.errorDeProceso = false;
    this.registroGrabado = false;
  }

  public selectAvatarToShow() {
    if (this.avatar === undefined || this.avatar === '') {
      this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
      this.errorEnAvatar = false;
    } else {
      this.avatarFile = $('#AvatarFile')[0].files[0];
      if (
        this.avatarFile['type'] !== 'image/jpeg' ||
        this.avatarFile['size'] > 40960
      ) {
        this.errorEnAvatar = true;
      } else {
        const reader: FileReader = new FileReader();
        reader.onloadend = () => {
          this.imageToShow = reader.result;
        };
        reader.readAsDataURL(this.avatarFile);
        this.errorEnAvatar = false;
      }
    }
  }

  /* Cuando se pulsa un botón de género se asigna
  su valor a la variable correspondiente. */
  public checkGender(gender) {
    this.genero = gender;
  }

  /* Cuando es un alta nueva se usa para poner como fecha de inscripción la del día. */
  private setActualDate() {
    this.fecha_de_ingreso = moment().format('YYYY-MM-DD');
  }

  /* Restauramos los campos del formulario como respuesta a una grabación correcta.
  Aquí no se llama a this.clearNotice(), para que permanezca el mensaje de grabación correcta. */
  private restoreData() {
    this.doiGrabar = undefined; // Para procesar sin espacios
    this.nombreGrabar = undefined; // Para procesar sin espacios
    this.imageToShow = this.connectService.URL + 'avatares/sin_avatar.jpg';
    this.activo = undefined;
    this.dataPack = new FormData();
    $('#MemberDataForm')[0].reset();
    this.setActualDate();
  }

  /* El siguiente método es invocado por el botón de reset del formulario. */
  public restoreMemberForm() {
    this.clearNotice();
    this.restoreData();
  }
}
