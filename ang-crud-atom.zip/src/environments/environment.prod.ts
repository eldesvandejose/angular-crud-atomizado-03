export const environment = {
  production: true,
  APIS_URL: 'http://localhost/aca_apis/'
};
