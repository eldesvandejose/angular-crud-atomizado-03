<?php
  include_once ('db_conn.php');

  // Recuperamos los datos del usuario
  $datosDeUsuario = json_decode($_POST["User"], true);

  
  // Tratamos de grabar los datos en la base de datos.
  $numeroDeError = "0";
  if ($datosDeUsuario["id"] == "0") { // Nueva inserción
    // Si tiene un avatar le creamos un nombre.
    // Si no lo tiene el nombre es sin_avatar.jpg
    if (isset($_FILES["Avatar"])) {
      $datosDeUsuario["nombreDeAvatar"] = "avatares/".md5(uniqid()).".jpg";
    } else {
      $datosDeUsuario["nombreDeAvatar"] = "avatares/sin_avatar.jpg";
    }
    $consulta = "INSERT INTO socios (";
    $consulta .= "doi, nombre, fecha_de_ingreso, genero, avatar, activo ";
    $consulta .= ") VALUES (";
    $consulta .= ":doi, :nombre, :fecha_de_ingreso, :genero, :avatar, :activo);";
  }

  $hacerConsulta = $conexion->prepare($consulta); // Se crea un objeto PDOStatement.
  $hacerConsulta->bindParam("doi", $datosDeUsuario['doi']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("nombre", $datosDeUsuario['nombre']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("fecha_de_ingreso", $datosDeUsuario['fecha_de_ingreso']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("genero", $datosDeUsuario['genero']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindParam("avatar", $datosDeUsuario['nombreDeAvatar']); // Se asigna un valor para la consulta.
  $hacerConsulta->bindValue("activo", "S"); // Se asigna un valor para la consulta.
  try {
    $hacerConsulta->execute(); // Se ejecuta la consulta.
  } catch (PDOException $e) {
    $numeroDeError = $e;
  }
  $hacerConsulta->closeCursor(); // Se libera el recurso.
  
  if ($numeroDeError == "0" && isset($_FILES["Avatar"])) {
    move_uploaded_file($_FILES["Avatar"]["tmp_name"], $datosDeUsuario["nombreDeAvatar"]);
  }

  $respuesta = json_encode($numeroDeError);
  echo $respuesta;
?>
