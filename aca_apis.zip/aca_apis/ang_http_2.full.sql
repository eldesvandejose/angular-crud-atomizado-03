-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-07-2018 a las 21:07:43
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ang_aca_miembros`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `socios`
--

CREATE TABLE IF NOT EXISTS `socios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doi` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `fecha_de_ingreso` date NOT NULL,
  `genero` enum('H','M') NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'sin_avatar.jpg',
  `activo` enum('S','N') NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_doi` (`doi`(191)) USING BTREE,
  KEY `nombre_index` (`nombre`(191)),
  KEY `fecha_de_ingreso_index` (`fecha_de_ingreso`),
  KEY `genero_index` (`genero`),
  KEY `avatar_index` (`avatar`(191)),
  KEY `activo_index` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `socios`
--

INSERT INTO `socios` (`id`, `doi`, `nombre`, `fecha_de_ingreso`, `genero`, `avatar`, `activo`) VALUES
(1, '994348938ZKDE', 'Agustín García Garrigues', '2015-04-25', 'H', 'avatares/lkfekl4flsk393909wjcffwj09fealjf.jpg', 'S'),
(2, '09ILK4LMWL4', 'Elisa Fernández De Lima', '2015-07-01', 'M', 'avatares/lknf4wlkmn9w4f94505oprwkrwrwjr43.jpg', 'S'),
(3, 'LJKRJFNK44S4', 'Manfredo Torres Redondo', '2016-05-18', 'H', 'avatares/kllwe924i99kñl23k40320rkrwo3wño0.jpg', 'S'),
(4, 'ASLKJ3LK4LRFLKF4', 'María Fernanda Gómez De La Causa', '2017-08-17', 'M', 'avatares/sin_avatar.jpg', 'S');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
